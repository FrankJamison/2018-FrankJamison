
			<div id="content_footer"></div>
			
			<div id="footer">
				Copyright &copy; Frank Jamison | 
				<a href="http://validator.w3.org/check?uri=referer" target="_blank">HTML5</a> | 
				<a href="http://jigsaw.w3.org/css-validator/check/referer" target="_blank">CSS</a>
			</div>