
	<head>
		<title>Frank's Classic Cars</title>
		<meta name="description" content="Welcome to Frank's Classic Cars. We are the largest Classic and Exotic Car Sales Company in the world specializing in classic, collector, antique, exotic and race cars in our complete indoor showroom. Financing offered on all vehicles to qualified buyers." />
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<link rel="stylesheet" type="text/css" href="../css/style.css" title="style" />
	</head>