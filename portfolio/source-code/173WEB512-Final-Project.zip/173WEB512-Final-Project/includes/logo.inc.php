
				<div id="logo">
        			<div id="logo_text">
          				<h1><a href="index.html">Frank's<span class="logo_colour">Classic Cars</span></a></h1>
          				<h2>Classic, collector, antique, exotic and race cars</h2>
        			</div>
      			</div>
