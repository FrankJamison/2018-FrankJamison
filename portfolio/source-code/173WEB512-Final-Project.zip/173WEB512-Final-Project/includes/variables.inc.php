<?php

	// Database Connection Variables
	$host = "fjamison.powwebmysql.com";
	$web_user = "user";
	$pwd = "webuser512";
	$dbname = "uc_davis_web512";
	$dbc = 0;

	// Product Line Variable
	$productLine = '';
	
?>