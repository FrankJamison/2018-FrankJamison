<?php

// Database Connection Variables
$host = "localhost";
$web_user = "user";
$pwd = "res0@L2018";
$dbname = "174web515project";
$charset = "utf8mb4";
$dbc = 0;

// Login Form Input Variables
$loginUsername = '';
$loginPassword = '';
$loginMd5HashPwd = '';

// Registration Form Input Variables
$registrationFirstName = "";
$registrationLastName = "";
$registrationEmailAddress = "";
$registrationUsername = "";
$registrationPassword = "";
$registrationMd5HashPwd = "";

$validFirstName = "";
$validLastName = "";
$validEmailAddress = "";
$validUsername = "";
$validPassword = "";

// Database Member Variables
$storedMemberID = '';
$storedMemberUsername = '';
$storedMemberPassword = '';
$storedMemberFirstName = '';
$storedMemberLastName = '';

?>