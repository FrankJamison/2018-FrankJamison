<?php

// Site constants
$ROOT = 'http://localhost/174WEB515/FinalProject';
    
?>

