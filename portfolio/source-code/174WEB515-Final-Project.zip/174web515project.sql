-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 30, 2018 at 11:42 PM
-- Server version: 5.7.21
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `174web515project`
--

-- --------------------------------------------------------

--
-- Table structure for table `alignments`
--

DROP TABLE IF EXISTS `alignments`;
CREATE TABLE IF NOT EXISTS `alignments` (
  `alignmentID` int(2) UNSIGNED NOT NULL AUTO_INCREMENT,
  `alignmentName` varchar(50) NOT NULL,
  PRIMARY KEY (`alignmentID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `alignments`
--

INSERT INTO `alignments` (`alignmentID`, `alignmentName`) VALUES
(1, 'Lawful Good'),
(2, 'Neutral Good'),
(3, 'Chaotic Good'),
(4, 'Lawful Neutral'),
(5, 'Neutral'),
(6, 'Chaotic Neutral'),
(7, 'Lawful Evil'),
(8, 'Neutral Evil'),
(9, 'Chaotic Evil'),
(10, 'Alignment');

-- --------------------------------------------------------

--
-- Table structure for table `backgrounds`
--

DROP TABLE IF EXISTS `backgrounds`;
CREATE TABLE IF NOT EXISTS `backgrounds` (
  `backgroundID` int(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `backgroundName` varchar(50) NOT NULL,
  PRIMARY KEY (`backgroundID`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `backgrounds`
--

INSERT INTO `backgrounds` (`backgroundID`, `backgroundName`) VALUES
(1, 'Acolyte'),
(2, 'Charlatan'),
(3, 'Criminal'),
(4, 'Entertainer'),
(5, 'Folk Hero'),
(6, 'Guild Artisan'),
(7, 'Hermit'),
(8, 'Noble'),
(9, 'Outlander'),
(10, 'Sage'),
(11, 'Sailor'),
(12, 'Soldier'),
(13, 'Urchin'),
(14, 'Pirate'),
(15, 'Knight'),
(16, 'Guild Merchant'),
(17, 'Gladiator'),
(18, 'Spy'),
(19, 'Background');

-- --------------------------------------------------------

--
-- Table structure for table `characters`
--

DROP TABLE IF EXISTS `characters`;
CREATE TABLE IF NOT EXISTS `characters` (
  `characterID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `characterName` varchar(100) DEFAULT NULL,
  `classID` int(3) UNSIGNED DEFAULT NULL,
  `levelID` int(2) UNSIGNED DEFAULT NULL,
  `backgroundID` int(3) UNSIGNED DEFAULT NULL,
  `userID` int(11) UNSIGNED NOT NULL,
  `raceID` int(3) UNSIGNED DEFAULT NULL,
  `alignmentID` int(1) UNSIGNED DEFAULT NULL,
  `experiencePoints` int(11) UNSIGNED DEFAULT NULL,
  `strengthScore` int(3) UNSIGNED DEFAULT NULL,
  `dexterityScore` int(3) UNSIGNED DEFAULT NULL,
  `constitutionScore` int(3) UNSIGNED DEFAULT NULL,
  `intelligenceScore` int(3) UNSIGNED DEFAULT NULL,
  `wisdomScore` int(3) UNSIGNED DEFAULT NULL,
  `charismaScore` int(3) UNSIGNED DEFAULT NULL,
  `inspiration` varchar(3) DEFAULT NULL,
  `strengthProficiency` tinyint(1) DEFAULT NULL,
  `dexterityProficiency` tinyint(1) DEFAULT NULL,
  `constitutionProficiency` tinyint(1) DEFAULT NULL,
  `intelligenceProficiency` tinyint(1) DEFAULT NULL,
  `wisdomProficiency` tinyint(1) DEFAULT NULL,
  `charismaProficiency` tinyint(1) DEFAULT NULL,
  `acrobaticsProficiency` tinyint(1) DEFAULT NULL,
  `animalHandlingProficiency` tinyint(1) DEFAULT NULL,
  `arcanaProficiency` tinyint(1) DEFAULT NULL,
  `athleticsProficiency` tinyint(1) DEFAULT NULL,
  `deceptionProficiency` tinyint(1) DEFAULT NULL,
  `historyProficiency` tinyint(1) DEFAULT NULL,
  `insightProficiency` tinyint(1) DEFAULT NULL,
  `intimidationProficiency` tinyint(1) DEFAULT NULL,
  `investigationProficiency` tinyint(1) DEFAULT NULL,
  `medicineProficiency` tinyint(1) DEFAULT NULL,
  `natureProficiency` tinyint(1) DEFAULT NULL,
  `perceptionProficiency` tinyint(1) DEFAULT NULL,
  `performanceProficiency` tinyint(1) DEFAULT NULL,
  `persuasionProficiency` tinyint(1) DEFAULT NULL,
  `religionProficiency` tinyint(1) DEFAULT NULL,
  `sleightOfHandProficiency` tinyint(1) DEFAULT NULL,
  `stealthProficiency` tinyint(1) DEFAULT NULL,
  `survivalProficiency` tinyint(1) DEFAULT NULL,
  `otherProficiencies` text,
  `armorClass` int(3) DEFAULT NULL,
  `initiative` int(3) DEFAULT NULL,
  `speed` varchar(5) DEFAULT NULL,
  `maxHitPoints` int(11) DEFAULT NULL,
  `currentHitPoints` int(11) DEFAULT NULL,
  `temporaryHitPoints` int(4) DEFAULT NULL,
  `totalHitDice` varchar(10) DEFAULT NULL,
  `remainingHitDice` varchar(10) DEFAULT NULL,
  `deathSuccess1` tinyint(1) DEFAULT NULL,
  `deathSuccess2` tinyint(1) DEFAULT NULL,
  `deathSuccess3` tinyint(1) DEFAULT NULL,
  `deathFail1` tinyint(1) DEFAULT NULL,
  `deathFail2` tinyint(1) DEFAULT NULL,
  `deathFail3` tinyint(1) DEFAULT NULL,
  `attackName1` varchar(50) DEFAULT NULL,
  `attackBonus1` varchar(6) DEFAULT NULL,
  `attackDamage1` varchar(50) DEFAULT NULL,
  `attackName2` varchar(50) DEFAULT NULL,
  `attackBonus2` varchar(6) DEFAULT NULL,
  `attackDamage2` varchar(50) DEFAULT NULL,
  `attackName3` varchar(50) DEFAULT NULL,
  `attackBonus3` varchar(6) DEFAULT NULL,
  `attackDamage3` varchar(50) DEFAULT NULL,
  `spellcasting` text,
  `copperPieces` int(11) UNSIGNED DEFAULT NULL,
  `silverPieces` int(11) UNSIGNED DEFAULT NULL,
  `electrumPieces` int(11) UNSIGNED DEFAULT NULL,
  `goldPieces` int(11) UNSIGNED DEFAULT NULL,
  `platinumPieces` int(11) UNSIGNED DEFAULT NULL,
  `equipment` text,
  `personality` text,
  `ideals` text,
  `bonds` text,
  `flaws` text,
  `features` text,
  PRIMARY KEY (`characterID`),
  KEY `backgroundID` (`backgroundID`) USING BTREE,
  KEY `levelID` (`levelID`) USING BTREE,
  KEY `classID` (`classID`) USING BTREE,
  KEY `userID` (`userID`),
  KEY `raceID` (`raceID`),
  KEY `alignmentID` (`alignmentID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `characters`
--

INSERT INTO `characters` (`characterID`, `characterName`, `classID`, `levelID`, `backgroundID`, `userID`, `raceID`, `alignmentID`, `experiencePoints`, `strengthScore`, `dexterityScore`, `constitutionScore`, `intelligenceScore`, `wisdomScore`, `charismaScore`, `inspiration`, `strengthProficiency`, `dexterityProficiency`, `constitutionProficiency`, `intelligenceProficiency`, `wisdomProficiency`, `charismaProficiency`, `acrobaticsProficiency`, `animalHandlingProficiency`, `arcanaProficiency`, `athleticsProficiency`, `deceptionProficiency`, `historyProficiency`, `insightProficiency`, `intimidationProficiency`, `investigationProficiency`, `medicineProficiency`, `natureProficiency`, `perceptionProficiency`, `performanceProficiency`, `persuasionProficiency`, `religionProficiency`, `sleightOfHandProficiency`, `stealthProficiency`, `survivalProficiency`, `otherProficiencies`, `armorClass`, `initiative`, `speed`, `maxHitPoints`, `currentHitPoints`, `temporaryHitPoints`, `totalHitDice`, `remainingHitDice`, `deathSuccess1`, `deathSuccess2`, `deathSuccess3`, `deathFail1`, `deathFail2`, `deathFail3`, `attackName1`, `attackBonus1`, `attackDamage1`, `attackName2`, `attackBonus2`, `attackDamage2`, `attackName3`, `attackBonus3`, `attackDamage3`, `spellcasting`, `copperPieces`, `silverPieces`, `electrumPieces`, `goldPieces`, `platinumPieces`, `equipment`, `personality`, `ideals`, `bonds`, `flaws`, `features`) VALUES
(1, 'Character 1', 1, 10, 3, 8, 18, 6, 100, 18, 14, 16, 8, 12, 16, '', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '', 0, 0, '0', 0, 0, 0, '1d12', '1d12', 1, 1, 1, 1, 1, 1, 'Dagger', '+6', '1d4+3', 'Flail', '+6', '1d8+3 Bludgeoning', 'Javalin', '+6', '1d6+3 Piercing', 'test2', 10, 30, 50, 70, 90, 'test3', 'test4', 'test5', 'test6', 'test7', 'test8&#039;'),
(2, 'Character 2', 13, 21, 19, 8, 20, 10, 0, 0, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 0, '0', 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, '', '', '', '', '', ''),
(3, 'Character 3', 13, 21, 19, 8, 20, 10, 0, 12, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 0, '0', 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, '', '', '', '', '', ''),
(4, 'Character 4', 13, 5, 19, 8, 20, 10, 0, 13, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 0, '0', 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, '', '', '', '', '', ''),
(5, 'Alexea', 3, 5, 8, 8, 17, 1, 6500, 16, 8, 16, 8, 8, 17, '+3', 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 'Languages:Orc, Common, Elvish, Draconic, \r\n\r\nProficiencies:Athletics, Charisma Saving Throws, Deception, Dice Set, Heavy Armor, History, Insight, Intimidation, Light Armor, Martial Weapons, Medium Armor, Persuasion, Shields, Simple Weapons, Wisdom Saving Throws, ', 19, -1, '30', 49, 49, 0, '5', '5', 0, 0, 0, 0, 0, 0, 'Dagger', '+6', '1d4+3', 'Flail', '+6', '1d8+3 Bludgeoning', 'Javalin', '+6', '1d6+3 Piercing', 'Longsword | +6 | 1d8+3 Slashing\r\nMorningstar | +6 | 1d8+3 Piercing', 2, 2, 0, 5, 12, '- Shield\r\n- Chain Mail\r\n- Dagger\r\n- Longsword\r\n- Javelin (5)\r\n- Flail\r\n- Morningstar\r\n- Backpack\r\n- Bedroll\r\n- Block and Tackle\r\n- Chain (10 feet)\r\n- Climber&#039;s Kit\r\n- Clothes, Fine\r\n- Crowbar\r\n- Fishing Tackle\r\n- Grappling Hook\r\n- Hammer\r\n- Healer&#039;s Kit\r\n- Holy Water (flask)\r\n- Lantern, Bullseye\r\n- Mess Kit\r\n- Mirror, Steel\r\n- Oil (flask) (5)\r\n- Pole (10-foot)\r\n- Potion of Healing (5)\r\n- Pouch\r\n- Rations (1 day) (10)\r\n- Rope, Silk (50 feet)\r\n- Sack\r\n- Shovel\r\n- Signal Whistle\r\n- Signet Ring\r\n- Soap', 'My eloquent flattery makes everyone I talk to feel like the most wonderful and important person in the world.\r\nDespite my noble birth, I do not place myself above other folk. We all have the same blood.	', 'Responsibility. It is my duty to respect the authority of those above me, just as those below me must respect mine. (Lawful)', 'The common folk must see me as a hero of the people.', 'I too often hear veiled insults and threats in every word addressed to me, and Iâ€™m quick to anger.', 'Paladin:\r\n- Divine Sense\r\n- Hit Points\r\n- Lay on Hands Pool\r\n- Proficiencies\r\n- Divine Smite\r\n- Fighting Style\r\n- Spellcasting\r\n- Channel Divinity\r\n- Divine Health\r\n- Oath Spells\r\n- Ability Score Improvement\r\n- Extra Attack\r\nRacial Traits:\r\n- Ability Score Increase\r\n- Darkvision\r\n- Fey Ancestry\r\n- Skill Versatility\r\n- Languages\r\n'),
(6, 'Character 6', 13, 21, 19, 8, 20, 10, 0, 0, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 0, '0', 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, '', '', '', '', '', ''),
(7, 'Character 1', 5, 1, 19, 9, 11, 2, 0, 18, 16, 14, 16, 16, 12, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 0, '0', 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, '', '', '', '', '', ''),
(8, 'Character 7', 13, 21, 19, 8, 20, 10, 0, 10, 10, 10, 10, 10, 10, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 0, '0', 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, '', '', '', '', '', ''),
(9, 'Character 8', 13, 21, 19, 8, 20, 10, 0, 10, 10, 10, 10, 10, 10, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 0, '0', 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, '', '', '', '', '', ''),
(10, 'Character 9', 13, 21, 19, 8, 20, 10, 0, 10, 10, 10, 10, 10, 10, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'test3', 0, 0, '0', 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, '', '', '', '', '', ''),
(11, 'Character 10', 13, 21, 19, 8, 20, 10, 0, 10, 10, 10, 10, 10, 10, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 0, '0', 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, '', '', '', '', '', ''),
(12, 'Character 11', 1, 5, 19, 8, 20, 10, 0, 10, 10, 10, 10, 10, 10, '', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, '', 0, 0, '0', 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

DROP TABLE IF EXISTS `classes`;
CREATE TABLE IF NOT EXISTS `classes` (
  `classID` int(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `className` varchar(50) NOT NULL,
  PRIMARY KEY (`classID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`classID`, `className`) VALUES
(1, 'Barbarian'),
(2, 'Bard'),
(3, 'Cleric'),
(4, 'Druid'),
(5, 'Fighter'),
(6, 'Monk'),
(7, 'Paladin'),
(8, 'Ranger'),
(9, 'Rogue'),
(10, 'Sorcerer'),
(11, 'Warlock'),
(12, 'Wizard'),
(13, 'Class');

-- --------------------------------------------------------

--
-- Table structure for table `levels`
--

DROP TABLE IF EXISTS `levels`;
CREATE TABLE IF NOT EXISTS `levels` (
  `levelID` int(2) UNSIGNED NOT NULL AUTO_INCREMENT,
  `levelNumber` varchar(3) NOT NULL,
  PRIMARY KEY (`levelID`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `levels`
--

INSERT INTO `levels` (`levelID`, `levelNumber`) VALUES
(1, '1'),
(2, '2'),
(3, '3'),
(4, '4'),
(5, '5'),
(6, '6'),
(7, '7'),
(8, '8'),
(9, '9'),
(10, '10'),
(11, '11'),
(12, '12'),
(13, '13'),
(14, '14'),
(15, '15'),
(16, '16'),
(17, '17'),
(18, '18'),
(19, '19'),
(20, '20'),
(21, 'Lvl');

-- --------------------------------------------------------

--
-- Table structure for table `races`
--

DROP TABLE IF EXISTS `races`;
CREATE TABLE IF NOT EXISTS `races` (
  `raceID` int(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `raceName` varchar(50) NOT NULL,
  PRIMARY KEY (`raceID`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `races`
--

INSERT INTO `races` (`raceID`, `raceName`) VALUES
(1, 'Dwarf, Standard'),
(2, 'Dwarf, Hill'),
(3, 'Dwarf, Mountain'),
(4, 'Elf, Standard'),
(5, 'Elf, High'),
(6, 'Elf, Wood'),
(7, 'Elf, Dark (Drow)'),
(8, 'Halfling, Standard'),
(9, 'Halfling, Lightfoot'),
(10, 'Halfling, Stout'),
(11, 'Human, Standard'),
(12, 'Human, Variant'),
(13, 'Dragonborn'),
(14, 'Gnome, Standard'),
(15, 'Gnome, Forest'),
(16, 'Gnome, Rock'),
(17, 'Half-Elf, Standard'),
(18, 'Half-Orc'),
(19, 'Tiefling, Standard'),
(20, 'Race');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `userID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `userFirstName` varchar(25) NOT NULL,
  `userLastName` varchar(25) NOT NULL,
  `userEmailAddress` varchar(50) NOT NULL,
  `userUsername` varchar(25) NOT NULL,
  `userHashedPassword` varchar(32) NOT NULL,
  PRIMARY KEY (`userID`),
  KEY `userID` (`userID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `userFirstName`, `userLastName`, `userEmailAddress`, `userUsername`, `userHashedPassword`) VALUES
(2, 'Robert', 'Rotsolk', 'rotsolk1000@gmail.com', 'Enigma18', 'a49f1a1ee5fbeb7a1d869c822ecd8379'),
(5, 'Frank', 'Jamison', 'frank@frankjamison.com', 'frankjamison', '1de17b7d1028523eb98187bff6d1f6fd'),
(6, 'Frank', 'Jamison', 'frankjamison@gmail.com', 'jamisonfc', '1de17b7d1028523eb98187bff6d1f6fd'),
(8, 'Julie', 'Jamison', 'jmjamison.jj@gmail.com', 'butterfly1', '680f89b70f74e1380486bc3230f70b96'),
(9, 'Brandon', 'Jamison', 'brandonjamison77@yahoo.com', 'LoneWolfC6', '3969525a080216b32cc196ae613145d0');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `characters`
--
ALTER TABLE `characters`
  ADD CONSTRAINT `characters_ibfk_1` FOREIGN KEY (`classID`) REFERENCES `classes` (`classID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `characters_ibfk_2` FOREIGN KEY (`levelID`) REFERENCES `levels` (`levelID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `characters_ibfk_3` FOREIGN KEY (`backgroundID`) REFERENCES `backgrounds` (`backgroundID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `characters_ibfk_4` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `characters_ibfk_5` FOREIGN KEY (`raceID`) REFERENCES `races` (`raceID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `characters_ibfk_6` FOREIGN KEY (`alignmentID`) REFERENCES `alignments` (`alignmentID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
