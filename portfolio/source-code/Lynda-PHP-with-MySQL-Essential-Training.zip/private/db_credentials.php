<?php

define("DB_SERVER", "localhost");
define("DB_USER", "webuser");
define("DB_PASS", "a10Zna5tH5TOEZlg");
define("DB_NAME", "globe_bank");

?>