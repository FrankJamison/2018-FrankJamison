      <footer>
          &copy; <?php echo date('Y'); ?> Globe Bank
      </footer>
  </body>
</html>

<!-- Disconnect from database -->
<?php db_disconnect($db); ?>