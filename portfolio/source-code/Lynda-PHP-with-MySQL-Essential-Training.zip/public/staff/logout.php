<?php
require_once('../../private/initialize.php');

log_out_admin();
    
redirect_to(url_for('/staff/login.php'));

?>
